// changes banner image to pixel ninjas
function nextImg(banner) {
  banner.src = "./images/pixel-ninjas-2.png";
}

// changes banner image to stone punk
function prevImg(banner) {
  banner.src = "./images/stonepunk.png";
}

// increase cart item count
function heart(count) {
  count.innerText++;
}
